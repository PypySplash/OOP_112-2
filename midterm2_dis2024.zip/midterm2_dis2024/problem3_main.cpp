#include <iostream>
#include <vector>
   
// fill in
const int CAPACITY = 100;

using namespace std;

class SharedArray 
{
private:
    int size;
    int* data;
public:
    SharedArray() 
    {
        data = new int[CAPACITY];
        cout << "Default Constructor is called" << endl;
    }
    SharedArray(int s) 
    {
        size = s;
        cout << "Constructor is called" << endl;
        cout << "Move Assignment" << endl;

    }
    // copy constructor(shallow copy)
    SharedArray(SharedArray& other) : size(other.size), data(other.data) 
    {
        cout << "Copy Constructor is called - Shallow copy" << endl;
    }
    // // assignment operator
    // SharedArray& opeator=(const SharedArray& other)
    // {
    //     if (this != &other)
    //     {

    //     }
    // }
    int& operator[](int index)
    {
      if (index < 0 || index >= size)
      {
          cout << "out of range" << endl;
      }
      return data[index];
    }
    friend ostream& operator<<(ostream& cout, const SharedArray& sa)
    {
        for (int i = 0; i < sa.size; i++)
        {
            cout << sa.data[i] << " ";
        }
        return cout;
    }
    int move(SharedArray&& sa)
    {
        data = sa.data;
        sa.data = nullptr;
    }
    void create() {};
};

SharedArray create() {
      return SharedArray(5);
}

int main(){
    SharedArray m;
    cout << "before call to create()" << endl;
    m = create();
    m[0] = 5;
    cout << "m: " << m;
    const SharedArray n(m);
    m[0] = 1;
    m[2] = n[0];
    cout << "m: " << m;
    cout << "n: " << n;
    SharedArray o;
    o = m;
    cout << "o: " << o;
    SharedArray p = move(create());
    cout << "before returning from main" << endl;
    return 0; 
}