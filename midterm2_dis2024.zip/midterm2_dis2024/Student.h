#ifndef STUDENT_H
#define STUDENT_H
// #include "Class.h"

using namespace std;
class Class;

class Student
{
private:
    string name;
    shared_ptr<Class> classPtr;
public:
    Student(const string& n) : name(n) {}
    void setClass(const shared_ptr<Class>& c) 
    {
        classPtr = c;
        cout << name << " is in: " << c->getName() << endl;
    }
    string getName() const {return name;}
    string getClassName() const {return classPtr->getName();}
    ~Student()
    {
        cout << "Student destructor: " << name << endl;
    }
};

#endif