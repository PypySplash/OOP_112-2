#include <iostream>
#include <memory>
class B; // Forward declaration
class A {
public:
std::weak_ptr<B> b_ptr; // Changed from shared_ptr to weak_ptr
A() { std::cout << "A Constructor\n"; }
~A() { std::cout << "A Destructor\n"; }
void connect(std::shared_ptr<B> b) {
b_ptr = b;
}
};
class B {
public:
std::shared_ptr<A> a_ptr;
B() { std::cout << "B Constructor\n"; }
~B() { std::cout << "B Destructor\n"; }
void connect(std::shared_ptr<A> a) {
a_ptr = a;
}
};

using namespace std;

int main() {
auto a = std::make_shared<A>();
auto b = std::make_shared<B>();
a->connect(b);
b->connect(a);
cout << a.use_count() << endl;
cout << b.use_count() << endl;
return 0;
}