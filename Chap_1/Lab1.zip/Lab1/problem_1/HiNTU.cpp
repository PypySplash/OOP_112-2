#include <iostream>
#include "HiNTU.h"
// namespace: 一種封裝方式：將不同函式功能封裝在不同的命名空間中
namespace ntu
{
    void HiNTU::welcomeToOOP()
    {
        std::cout<<"Hello students of OOP!! Let's learn C++!!!"<<std::endl;
    }
}