#include "HiNTU.h"

int main()
{
    ntu::HiNTU n;
    n.welcomeToOOP();

    return 0;
}