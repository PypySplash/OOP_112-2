#ifndef HINTU_H
#define HINTU_H
// namespace: 一種封裝方式：將不同函式功能封裝在不同的命名空間中
namespace ntu{
    class HiNTU{
       public:
       void welcomeToOOP();
    };
}
#endif