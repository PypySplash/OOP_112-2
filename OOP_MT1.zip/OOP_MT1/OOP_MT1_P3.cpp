#include <iostream>
#include <vector>
#include <map>
#include <deque>
#include <string>
#include <queue>
#include <stack>

using namespace std;

struct Person
{
    string name;
    int age;
};

int main()
{
    // deque<Person> dq;
    stack<Person> stack;
    deque<Person> dq;
    vector<string> vec;
    string inputString;
    string name;
    int age;
    // 處理字串不能Google太痛苦惹><
    while (cin >> inputString)
    {
        vec.push_back(inputString);
    }
    for (int i = 0; i < inputString.size(); i++)
    {
        Person p;
        p.name = inputString[2 * i];
        p.age = inputString[2 * i + 1];

        stack.push(p);
    }
    while(stack.size() > 1)
    {
        dq.push_front(stack.top());
        stack.pop();
    }
    while(dq.size() > 0)
    {
        stack.push(dq.back());
        dq.pop_back();
    }
    while (stack.size() > 0)
    {
        Person temp = stack.top();
        cout << temp.name << ", " << temp.age << endl;
        stack.pop();
    }
    
}

