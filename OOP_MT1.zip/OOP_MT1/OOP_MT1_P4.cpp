#include <iostream>
#include <map>
#include <string>
#include <vector>
using namespace std;

int main()
{
    map<string, int> charCounts;
    // 創建一個字典，儲存單字以及其次數（不確定Ｃ＋＋的字典叫什麼）
    string givenString;
    cout << "Given string: ";
    cin >> givenString;

    for (auto i : givenString)
    {
        // 使用for迴圈，或建立一個char指針，指到一個字母就將其放入字典
    }
    // 最後輸出第一個找到次數為1的字母
}